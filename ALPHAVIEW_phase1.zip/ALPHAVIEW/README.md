# ALPHAVIEW

Phase 1 front-end prototype for the crypto intelligence platform.

## Run
Open `index.html` in a browser.

## Current state
- Dark financial dashboard UI
- Responsive layout
- Demo BTC chart
- Demo market ticker
- AI probability UI
- Portfolio / signals / news panels

## Next
1. Real market API
2. Real chart data
3. Login + database
4. AI prediction engine
5. Trade journal
6. Standard/VIP permissions
7. Payments
