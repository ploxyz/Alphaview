const canvas=document.getElementById("priceChart");const ctx=canvas.getContext("2d");
function resizeChart(){const dpr=window.devicePixelRatio||1,r=canvas.getBoundingClientRect();canvas.width=r.width*dpr;canvas.height=r.height*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);drawChart(r.width,r.height)}
function drawChart(w,h){ctx.clearRect(0,0,w,h);let y=h*.55,pts=[];for(let i=0;i<76;i++){y+=(Math.random()-.43)*18;y=Math.max(h*.16,Math.min(h*.72,y));pts.push(y)}
const step=w/pts.length,cw=Math.max(3,step*.52);
ctx.beginPath();ctx.strokeStyle="#d8a63a";ctx.lineWidth=1.2;pts.forEach((p,i)=>{const yy=p-35;if(i===0)ctx.moveTo(i*step,yy);else ctx.lineTo(i*step,yy)});ctx.stroke();
pts.forEach((y,i)=>{const x=i*step+step/2,open=y+(Math.random()-.5)*14,close=y+(Math.random()-.5)*14,high=Math.min(open,close)-Math.random()*13-4,low=Math.max(open,close)+Math.random()*13+4,bull=close<open;ctx.strokeStyle=bull?"#00d69a":"#ff5266";ctx.fillStyle=ctx.strokeStyle;ctx.beginPath();ctx.moveTo(x,high);ctx.lineTo(x,low);ctx.stroke();ctx.fillRect(x-cw/2,Math.min(open,close),cw,Math.max(2,Math.abs(close-open)))});
pts.forEach((_,i)=>{const x=i*step+step/2,vol=10+Math.random()*27;ctx.fillStyle=i%5===0?"#8f454b":"#146a5c";ctx.fillRect(x-cw/2,h-vol,cw,vol)})}
window.addEventListener("resize",resizeChart);resizeChart();
